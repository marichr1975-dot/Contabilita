import SwiftUI
import UIKit
import Vision

struct BollettaOCRResult {
    let date: Date?
    let quantities: [String: Int]
    let rawText: String
}

struct BollettaScannerView: UIViewControllerRepresentable {
    let articleNames: [String]
    let completion: (BollettaOCRResult) -> Void
    @Environment(\.presentationMode) private var presentationMode

    func makeCoordinator() -> Coordinator {
        Coordinator(articleNames: articleNames, completion: completion, dismiss: { self.presentationMode.wrappedValue.dismiss() })
    }

    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.sourceType = UIImagePickerController.isSourceTypeAvailable(.camera) ? .camera : .photoLibrary
        picker.cameraCaptureMode = .photo
        picker.delegate = context.coordinator
        picker.allowsEditing = false
        return picker
    }

    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) { }

    final class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
        let articleNames: [String]
        let completion: (BollettaOCRResult) -> Void
        let dismiss: () -> Void

        init(articleNames: [String], completion: @escaping (BollettaOCRResult) -> Void, dismiss: @escaping () -> Void) {
            self.articleNames = articleNames
            self.completion = completion
            self.dismiss = dismiss
        }

        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) { dismiss() }

        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            guard let image = info[.originalImage] as? UIImage, let cgImage = image.cgImage else { dismiss(); return }
            let articleNames = self.articleNames
            let completion = self.completion
            let dismiss = self.dismiss
            let request = VNRecognizeTextRequest { request, _ in
                let observations = (request.results as? [VNRecognizedTextObservation]) ?? []
                let result = Self.parse(observations, articleNames: articleNames)
                DispatchQueue.main.async { completion(result); dismiss() }
            }
            request.recognitionLevel = .accurate
            request.usesLanguageCorrection = true
            request.recognitionLanguages = ["it-IT", "en-US"]
            request.minimumTextHeight = 0.008

            let orientation = Self.cgOrientation(from: image.imageOrientation)
            DispatchQueue.global(qos: .userInitiated).async {
                do {
                    let handler = VNImageRequestHandler(cgImage: cgImage, orientation: orientation, options: [:])
                    try handler.perform([request])
                } catch {
                    DispatchQueue.main.async {
                        completion(BollettaOCRResult(date: nil, quantities: [:], rawText: "ERRORE: impossibile leggere la foto."))
                        dismiss()
                    }
                }
            }
        }

        private static func cgOrientation(from orientation: UIImage.Orientation) -> CGImagePropertyOrientation {
            switch orientation {
            case .up: return .up
            case .down: return .down
            case .left: return .left
            case .right: return .right
            case .upMirrored: return .upMirrored
            case .downMirrored: return .downMirrored
            case .leftMirrored: return .leftMirrored
            case .rightMirrored: return .rightMirrored
            @unknown default: return .up
            }
        }

        private struct OCRLine { let text: String; let box: CGRect }

        private static func parse(_ observations: [VNRecognizedTextObservation], articleNames: [String]) -> BollettaOCRResult {
            let lines = observations.compactMap { obs -> OCRLine? in
                guard let text = obs.topCandidates(1).first?.string, !text.isEmpty else { return nil }
                return OCRLine(text: text.trimmingCharacters(in: .whitespacesAndNewlines), box: obs.boundingBox)
            }
            let ordered = lines.sorted {
                if abs($0.box.midY - $1.box.midY) > 0.018 { return $0.box.midY > $1.box.midY }
                return $0.box.minX < $1.box.minX
            }
            let rawText = ordered.map(\.text).joined(separator: "\n")
            return BollettaOCRResult(date: extractDate(from: ordered), quantities: extractQuantities(from: ordered, names: articleNames), rawText: rawText)
        }

        private static func normalizedOCR(_ text: String) -> String {
            text
                .replacingOccurrences(of: "O", with: "0")
                .replacingOccurrences(of: "o", with: "0")
                .replacingOccurrences(of: "I", with: "1")
                .replacingOccurrences(of: "l", with: "1")
                .replacingOccurrences(of: "|", with: "1")
        }

        private static func extractDate(from lines: [OCRLine]) -> Date? {
            let calendar = Calendar(identifier: .gregorian)
            let patterns = [
                #"(?<!\d)(\d{1,2})\s*[./-]\s*(\d{1,2})\s*[./-]\s*(\d{2,4})(?!\d)"#,
                #"(?<!\d)(\d{1,2})\s+(\d{1,2})\s+(\d{4})(?!\d)"#
            ]
            for line in lines {
                let text = normalizedOCR(line.text)
                for pattern in patterns {
                    guard let regex = try? NSRegularExpression(pattern: pattern) else { continue }
                    let range = NSRange(text.startIndex..<text.endIndex, in: text)
                    guard let m = regex.firstMatch(in: text, range: range), m.numberOfRanges >= 4 else { continue }
                    let day = Int((text as NSString).substring(with: m.range(at: 1))) ?? 0
                    let month = Int((text as NSString).substring(with: m.range(at: 2))) ?? 0
                    var year = Int((text as NSString).substring(with: m.range(at: 3))) ?? 0
                    if year < 100 { year += 2000 }
                    if (1...31).contains(day), (1...12).contains(month), let date = calendar.date(from: DateComponents(year: year, month: month, day: day)) { return date }
                }
            }
            return nil
        }

        private static func extractQuantities(from lines: [OCRLine], names: [String]) -> [String: Int] {
            var result: [String: Int] = [:]
            for name in names {
                let nName = normalize(name)
                guard !nName.isEmpty else { continue }
                let matches = lines.enumerated().filter { normalize($0.element.text).contains(nName) || fuzzyEnough(normalize($0.element.text), nName) }
                guard let (idx, article) = matches.min(by: { abs($0.1.box.midY - 0.5) < abs($1.1.box.midY - 0.5) }) else { continue }

                var candidates: [(Int, CGFloat, Int)] = []
                for (j, line) in lines.enumerated() {
                    let dy = abs(line.box.midY - article.box.midY)
                    guard dy < 0.10 else { continue }
                    let nums = numbers(in: line.text)
                    for value in nums where value >= 0 && value <= 9999 {
                        if j == idx {
                            candidates.append((value, 0, 0))
                        } else {
                            let dx = line.box.minX - article.box.maxX
                            let alignment = abs(line.box.midX - article.box.maxX)
                            candidates.append((value, dy + max(0, -dx) * 0.2 + alignment * 0.1, 1))
                        }
                    }
                }
                if let best = candidates.sorted(by: { $0.1 < $1.1 }).first { result[name] = best.0 }
            }
            return result
        }

        private static func numbers(in text: String) -> [Int] {
            let t = normalizedOCR(text).replacingOccurrences(of: ",", with: " ").replacingOccurrences(of: ".", with: " ")
            return t.split(whereSeparator: { !$0.isNumber }).compactMap { Int($0) }
        }

        private static func normalize(_ text: String) -> String {
            text.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: .current).filter { $0.isLetter || $0.isNumber }
        }

        private static func fuzzyEnough(_ a: String, _ b: String) -> Bool {
            guard a.count >= 5, b.count >= 5, abs(a.count - b.count) <= 3 else { return false }
            return levenshtein(a, b) <= 2
        }

        private static func levenshtein(_ a: String, _ b: String) -> Int {
            let a = Array(a), b = Array(b); var row = Array(0...b.count)
            for i in 1...a.count {
                var next = [i]
                for j in 1...b.count { next.append(min(row[j] + 1, next[j - 1] + 1, row[j - 1] + (a[i - 1] == b[j - 1] ? 0 : 1))) }
                row = next
            }
            return row[b.count]
        }
    }
}
